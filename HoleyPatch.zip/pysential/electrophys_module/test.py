from .heka_reader import *

filename = '210715_002.dat'