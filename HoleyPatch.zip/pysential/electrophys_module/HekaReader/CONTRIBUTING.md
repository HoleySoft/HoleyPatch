Any constructive contributions are welcome!
Happy patching!
