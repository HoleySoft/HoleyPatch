
import re

class FileFormatConverter:
    def __init__(self):
        pass

    def convert(self, filename):